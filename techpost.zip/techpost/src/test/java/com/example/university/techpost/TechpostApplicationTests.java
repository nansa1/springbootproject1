package com.example.university.techpost;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TechpostApplicationTests {

	@Test
	void contextLoads() {
	}

}
