package com.example.university.techpost.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.university.techpost.models.Post;
import com.example.university.techpost.models.User;


@Repository
public interface PostRepository extends JpaRepository<Post, Long> {

	List<Post> findAllByUser(User user);
	List<Post> findAllByTitle(String title);
	
	List<Post> findAllByLikes(Integer likes);
	List<Post> findAllByCategory(String category);
	
	void deleteAllByTitle(String post);
	boolean existsByTitle(String title);
	boolean existsByUser(User user);
	List<Post> findAllByLikesGreaterThan(int count);
	List<Post> findAllByLikesLessThan(int count);
}
