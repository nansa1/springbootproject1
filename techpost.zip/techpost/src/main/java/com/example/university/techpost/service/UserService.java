package com.example.university.techpost.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.university.techpost.models.Post;
import com.example.university.techpost.models.User;
import com.example.university.techpost.repository.PostRepository;
import com.example.university.techpost.repository.UserRepository;

@Service
public class UserService {
	@Autowired
	private UserRepository repo;
	@Autowired
	private PostRepository prepo;
	public User getUserByUsername(String username) {
		return repo.findByUsername(username);
	}
	//Retrieves all posts created by a specific user.
	
	public List<Post> getAllPostByUser(User user){
		return prepo.findAllByUser(user);
	}
	
//	public Post updatePostContent(Long postId, String newContent) {
//        Optional<Post> optionalPost = prepo.findById(postId);
//        if (optionalPost.isPresent()) {
//            Post post = optionalPost.get();
//            post.setContent(newContent);
//            return prepo.save(post);
//        }
//        return null;
//    }
	
	//Retrieves posts with likes count greater than a specified value.
	public List<Post> getPostsByLikesGreaterThan(int count) {
		return prepo.findAllByLikesGreaterThan(count);
	}
	public List<Post> findAllByLikesLessThan(int count) {
		return prepo.findAllByLikesLessThan(count);
	}
	
	public void deleteByTitle(String post) {
		prepo.deleteAllByTitle(post);
	}
}
