package com.example.university.techpost.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.university.techpost.models.Post;
import com.example.university.techpost.repository.PostRepository;
import com.example.university.techpost.service.PostService;

@RestController
@RequestMapping("/api")
public class PostController {
	@Autowired
	private PostRepository repo;
	@Autowired
	PostService service;
	
	@PostMapping("createpost")
	public void createPost(@RequestBody Post post) {
		repo.save(post);
	}
	
	@GetMapping("getpost")
	public List<Post> getPost() {
		return repo.findAll();
	}
}
