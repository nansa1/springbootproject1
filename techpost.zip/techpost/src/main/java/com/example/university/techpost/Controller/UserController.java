package com.example.university.techpost.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.university.techpost.models.Post;
import com.example.university.techpost.models.User;
import com.example.university.techpost.repository.PostRepository;
import com.example.university.techpost.repository.UserRepository;
import com.example.university.techpost.service.UserService;

@RestController
@RequestMapping("/api")
public class UserController {
	@Autowired
	private UserRepository repo;
	@Autowired
	private UserService userservice;
	@Autowired
	private PostRepository prepo;
	
	@GetMapping
	public String welcome() {
		return "Welcome";
	}
	@PostMapping("createuser")
	public void createUser(@RequestBody User user) {
		repo.save(user);
	}
	
	@GetMapping("showuser")
	public List<User> showUser() {
		return repo.findAll();
	}
	@GetMapping("showuserbyid/{id}")
	public Optional<User> showUserById(@PathVariable(value="id") Long id) {
		return repo.findById(id);
	}
	
	@PutMapping("updateuser/{id}")
	public User updateUser(@RequestBody User user,@PathVariable Long id) {
		user.setId(id);
		return repo.save(user);
	}
	
	@DeleteMapping("deleteuser/{id}")
	public void deleteUser(@PathVariable Long id) {
		repo.deleteById(id);
	}
	
	@GetMapping("userbyuser/{username}")
	public User getUserByUsername(@PathVariable String username) {
		return userservice.getUserByUsername(username);
	}
	
	@GetMapping("postbytitle/{title}")
	public List<Post> postByTitle(@PathVariable String title) {
		return prepo.findAllByTitle(title);
	}
	@GetMapping("getAllPostByUser/{username}")
	public List<Post> getAllPostByUser(@PathVariable String username) {
		User user = userservice.getUserByUsername(username);
		return userservice.getAllPostByUser(user);
		
	}
	@PostMapping("updatepostcontent/{id}")
	public void updatePostContent(@PathVariable Long id,@RequestBody String content) {
		Optional<Post> upost = prepo.findById(id);
		Post post= upost.get();
		post.setContent(content);
	}
	
	@DeleteMapping("deletepostbytitle/{title}")
	public void deletePostByTitle(@PathVariable String title) {
		//prepo.deleteAllByTitle(title);
//		List<Post> post = prepo.findAllByTitle(title);
//		userservice.deleteByTitle(title);
		//		User user = userservice.getUserByUsername(username);
//		System.out.println(prepo.existsByUser(user));
	}
	@GetMapping("getpostbylike/{likes}")
	public List<Post> getPostsByLikesGreaterThan(@PathVariable Integer likes) {
		return userservice.getPostsByLikesGreaterThan(likes);
	}
	@GetMapping("getpostbylesslike/{likes}")
	public List<Post> getPostsByLikeslessThan(@PathVariable Integer likes) {
		return userservice.findAllByLikesLessThan(likes);
	}
	
	
}
